<?php
 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
     
    // Retrieve form data
    $name = $_POST['name'];
    $mail = $_POST['mail'];
    $comment = $_POST['comment'];

    // Send email
    $to = "fl3xname@gmail.com";
    $subject = "flexname";
    $message = "Name : $name\nGmail : $mail\nComment : $comment\n";
    $headers = "From: info@flexname.fun";
    mail($to, $subject, $message, $headers);

 
   

}


?>


<!DOCTYPE html>
<html lang="en">

<head>
    
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
<link rel="stylesheet" href="mobile.css"/>
<link rel="stylesheet" href="screen_768px.css"/>
<link rel="stylesheet" href="screen_1024px.css"/>
<link rel="stylesheet" href="styles.css"/>
 <script>
        if ( window.history.replaceState ) {
            window.history.replaceState( null, null, window.location.href );
        }
    </script>
    <!-- icon cdn bootstrap-->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    />
    <title>flexname</title>
            <script>
    // Function to show/hide content sections based on ID
    function showSection(sectionId) {
        // Hide all content sections
        const sections = document.querySelectorAll('.content-section');
        sections.forEach(section => {
            section.style.display = 'none';
        });

        // Show the selected section
        const selectedSection = document.getElementById(sectionId);
        if (selectedSection) {
            selectedSection.style.display = 'block';
        }

        // Update URL hash to reflect the current section
        window.location.hash = sectionId;
    }

    // Function to show the appropriate section based on URL hash (on page load)
    window.onload = function() {
        const hash = window.location.hash.substr(1); // Get hash without the leading '#'
        if (hash !== '') {
            showSection(hash); // Show the section corresponding to the hash
        } else {
            showSection('home'); // Default to showing the home section if no hash is present
        }
    };
</script>

<style>
        @media screen and (max-width:600px) {
  

  :root {
            --primary-color:#CB5456;
            --primary-dark: #1F252E;
            --primary-dark:#324841;
            --font-size:10px;
        }

.home_btn
{
    display:none;

    
}



    /* Section 1 */
        .mode i {
            font-size: var( --font-size);
            cursor: pointer;
            color: var(--primary-color);
            opacity: 0;
            animation: rightSideAni 1.5s ease forwards;
            margin-top:5px;
            margin-left:15px;
        }


            header {
                height: auto;
            }

   li a {
            display: inline-block;
            padding: 0px 10px;
            color: var(--nav-text);
            text-decoration: none;
            font-size:10px;
            transition: .3s;
            opacity: 0;
            animation: navani .3s ease forwards;
            animation-delay: calc(.15s * var(--navAni));
        }

          
            .main h3 {
            font-size: 1.5rem;
            opacity: 0;
            animation: topSideAni 1s ease forwards;
        }

        .main h1 {
          font-size:2rem;
            font-weight: 600;
            opacity: 0;
            animation: leftSideAni 1s ease forwards;
            animation-delay: 1s;
        }

           


            .images {
                width: 100%;
                margin:0px auto;
            }

            .main {
                margin-top: 2rem;
            }
            
            
            
                .contact_page form input
        {
            border:none;
            outline:none;
            padding:15px 20px;
            border-radius:5px;
            margin:0px ;
            color:var(--primary-color);
            caret-color:var(--primary-color);;
              background: rgba(0, 0, 0, 0.2);
  -webkit-backdrop-filter: blur(10px);
  backdrop-filter: blur(10px);
   width: 100%;
    box-sizing: border-box; 
     font-size: var( --font-size);
     text-transform:capitalize;
     margin-bottom:3px;
    
        }
            
            
            
        }
        
               @media screen and (max-width: 768px) {
            .container {
                padding: 0 1.6rem;
            }
            
            

            
        }
        
</style>
</head>

<body>
    <header class="container">
        <div class="page-header">
            <div class="logo">
               <ul> <li> <a href="#home" onclick="showSection('home'); return false;" >FLEXNAME</a></li></ul>
            </div>
          

        
            <ul>
                <li><a href="#home"  style="--navAni:1" onclick="showSection('home'); return false;" class="home_btn">Home</a></li>
                <li><a href="#about" style="--navAni:2" onclick="showSection('about'); return false;">About</a></li>
                <li><a href="#contact" style="--navAni:5" onclick="showSection('contact'); return false;">Contact</a></li>
                <li>     
                <label class="mode">
                <input type="checkbox" id="darkModeToggle">
                <i class='bx bxs-moon'></i>
            </label>
            </li>
         
            </ul>
           
        </div>
    </header>


    <section class="container content-section" id="home" >
        <div class="main">
            <div class="detail">
                <h3>Hi, It's Me</h3>
                <h1>I'm <span style="color:var(--primary-color);">Mohd Rihan</span></h1>
                <p> a passionate web designer based in Kairana.
                My mission is to create stunning and user-friendly websites that help businesses thrive online.
                </p>
                <div class="social">
                    <a href="https://t.me/fl3xname" style="--socialAni:1"><i class='bx bxl-telegram'></i></a>
                    <a href="https://instagram.com/flexname" style="--socialAni:2"><i class='bx bxl-instagram'></i></a>
                    <a href="mailto:fl3xname@gmail.com" style="--socialAni:3"><i class='bx bxl-gmail'></i></a>
                    <a href="https://facebook.com/fl3xname " style="--socialAni:4"><i class='bx bxl-facebook-circle'></i></a>
                </div>
            </div>
           <div class="img-sec">
        <div class="images">
            <!-- Image element with click event inline JavaScript -->
             <img src="https://flexname.fun/flexname-9.jpg"
             alt="Image" class="img-w" 
             onclick="changeImage()">
        </div>
    </div>

        </div>
    </section>
    
    
    
    
    
    
    
      <section class="container content-section about_page" id="about" >
      
  
    
    <section>
        <h2>Welcome to Flexname</h2>
        <p>
            My name is Mohd Rihan, and I am dedicated to crafting unique digital experiences. Flexname is where creativity meets technology, empowering you to establish a distinctive online presence.
        </p>
    </section>

    <section>
        <h2>Our Mission</h2>
        <p>
            At Flexname, our mission is to fulfill your digital needs with excellence. We are committed to delivering high-quality, user-friendly, and visually striking websites that bring your vision to life in the digital world. Each project is approached with fresh perspectives to ensure your online business shines.
        </p>
    </section>

    <section>
        <h2>My Experience</h2>
        <p>
            I, Mohd Rihan, have over 3 years of experience as a website designer. Throughout my journey, I have assisted numerous businesses, professionals, and startups in establishing their online presence. My perspective has always been to transform each website into a compelling narrative that resonates with your audience.
        </p>
    </section>



    <footer>
        <p>If you need assistance with your website or digital project, Flexname is always here for you. We are committed to turning your dreams into reality in the digital world.</p>
        <p>Thank you!</p>
    </footer>
          </section>
          
          
          
          
             <div class="container content-section contact_page" id="contact">

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" >
    <input type="text" id="name" name="name" required placeholder="Your Name" minlength="3" maxlength="22" autocomplete="off">
    
    <input type="email" id="mail" name="mail" placeholder="Your Gmail"  minlength="8"     pattern="[a-zA-Z0-9._%+-]+@gmail\.com$"  required autocomplete="off" style="text-transform:lowercase;">
    
    <input type="text" id="comment" name="comment" placeholder="Comment" required autocomplete="off">
    
    <input type="submit" name="submit" value="Submit">
</form>

                </div>
                </div>
                </div>
          
          
    <script>
        const darkModeToggle = document.getElementById('darkModeToggle');
        const body = document.body;
        const isDarkMode = localStorage.getItem('darkMode') === 'enabled';
        if (isDarkMode) {
            body.classList.add('dark-mode');
            darkModeToggle.checked = true;
        }
        darkModeToggle.addEventListener('change', () => {
            if (darkModeToggle.checked) {
                body.classList.add('dark-mode');
                localStorage.setItem('darkMode', 'enabled');
            } else {
                body.classList.remove('dark-mode');
                localStorage.setItem('darkMode', 'disabled');
            }
        });
    </script>
    
    
  <script>
document.addEventListener("DOMContentLoaded", function() {
    const links = document.querySelectorAll('ul li a');

    // Function to handle scrolling to the correct section
    function scrollToSection(targetId) {
        const targetSection = document.getElementById(targetId);
        if (targetSection) {
            // Scroll to the section smoothly
            targetSection.scrollIntoView({ behavior: 'smooth' });

            // Add 'active' class to the corresponding link
            links.forEach(link => {
                if (link.getAttribute('href') === `#${targetId}`) {
                    link.classList.add('active');
                } else {
                    link.classList.remove('active');
                }
            });
        }
    }

    // Add click event listener to each link
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault(); // Prevent default link behavior
            const targetId = this.getAttribute('href').substring(1);
            scrollToSection(targetId);
        });
    });

    // Handle initial scroll based on URL hash
    if (window.location.hash) {
        const initialTargetId = window.location.hash.substring(1);
        scrollToSection(initialTargetId);
    }
});


  </script>



    <script>
        // Array of image URLs
        const imageUrls = [
            "https://flexname.fun/flexname-9.jpg",
            "https://flexname.fun/flexname-1.jpg",
            "https://flexname.fun/flexname-4.jpg",
            "https://flexname.fun/flexname-5.jpg",
            "https://flexname.fun/flexname-10.jpg",
            "https://flexname.fun/flexname-37.jpg",
            "https://flexname.fun/flexname-24.jpg",
            "https://flexname.fun/flexname-11.jpg",
            "https://flexname.fun/flexname-51.jpg",
            "https://flexname.fun/flexname-6.jpg",
            "https://flexname.fun/flexname-2.jpg",
            "https://flexname.fun/flexname-42.jpg",
            "https://flexname.fun/flexname-43.jpg",
            "https://flexname.fun/flexname-44.jpg",
            "https://flexname.fun/flexname-38.jpg",
            "https://flexname.fun/flexname-27.jpg",
            "https://flexname.fun/flexname-13.jpg",
            "https://flexname.fun/flexname-14.jpg",
            "https://flexname.fun/flexname-28.jpg",
            "https://flexname.fun/flexname-29.jpg",
            "https://flexname.fun/flexname-30.jpg",
            "https://flexname.fun/flexname-31.jpg",
            "https://flexname.fun/flexname-15.jpg",
            "https://flexname.fun/flexname-16.jpg",
            "https://flexname.fun/flexname-33.jpg",
            "https://flexname.fun/flexname-52.jpg",
            "https://flexname.fun/flexname-34.jpg",
            "https://flexname.fun/flexname-36.jpg",
            "https://flexname.fun/flexname-57.jpg",
            "https://flexname.fun/flexname-58.jpg",
            "https://flexname.fun/flexname-59.jpg",
            "https://flexname.fun/flexname-60.jpg",
            "https://flexname.fun/flexname-40.jpg",
            "https://flexname.fun/flexname-41.jpg"
            // Add more image URLs here as needed
        ];

        let currentIndex = 0;
        const imgElement = document.querySelector('.img-w');

        function changeImage() {
            currentIndex = (currentIndex + 1) % imageUrls.length;
            imgElement.src = imageUrls[currentIndex];
        }
    </script>
</body>

</html>